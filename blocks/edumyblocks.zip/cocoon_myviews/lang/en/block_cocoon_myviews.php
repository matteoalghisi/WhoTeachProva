<?php
$string['pluginname'] = '[Cocoon] My Profile Views';
$string['cocoon_myviews'] = '[Cocoon] My Profile Views';
$string['cocoon_myviews:addinstance'] = 'Add a new My Profile Views block';
$string['cocoon_myviews:myaddinstance'] = 'Add a new My Profile Views block to the My Moodle page';
$string['title'] = 'Your Profile Views';
$string['subtitle'] = 'An overview of your profile visits over the last week';
$string['dataset'] = 'Visits';
