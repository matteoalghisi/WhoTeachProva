<?php

$string['configtitle'] = 'Block title';
$string['cocoon_faqs:addinstance'] = 'Add a new Custom slider block';
$string['cocoon_faqs:myaddinstance'] = 'Add a new Custom slider block to Dashboard';
$string['leaveblanktohide'] = 'leave blank to hide the title';
$string['newcustomsliderblock'] = '(new Custom slider block)';
$string['pluginname'] = '[Cocoon] FAQs';

$string['slides_number'] = 'Number of slides';
$string['config_title'] = 'Title';
$string['config_faq_title'] = 'FAQ title';
$string['config_faq_subtitle'] = 'FAQ subtitle';
$string['config_faq_body'] = 'FAQ body';
