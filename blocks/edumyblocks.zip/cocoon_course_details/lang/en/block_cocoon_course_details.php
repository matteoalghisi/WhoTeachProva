<?php
$string['pluginname'] = '[Cocoon] Course Enrolment';
$string['cocoon_course_details'] = '[Cocoon] Course Enrolment';
$string['cocoon_course_details:addinstance'] = 'Add a new Course Enrolment block';
$string['cocoon_course_details:myaddinstance'] = 'Add a new Course Enrolment block to the My Moodle page';
$string['config_item_title'] = 'Item title';
$string['config_item_icon'] = 'Item icon';
$string['config_items'] = 'Number of items';
$string['course_enrolment'] = 'Buy & Enrol Now';
$string['course_buy_access'] = 'Paid course entry';
$string['course_enrolled'] = 'You\'re enrolled';
$string['course_enrolled_text'] = 'You are currently enrolled in this course.';
$string['course_error_title'] = 'Enrolment Error';
$string['course_error_text'] = 'Your administrator has not yet configured PayPal or Stripe Enrolment for this course.';
$string['course_price'] = 'Price';
$string['course_currency'] = '$';
