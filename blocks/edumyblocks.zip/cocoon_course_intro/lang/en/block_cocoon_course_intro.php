<?php
$string['pluginname'] = '[Cocoon] Course Intro';
$string['cocoon_course_intro'] = '[Cocoon] Course Intro';
$string['cocoon_course_intro:addinstance'] = 'Add a new Course Intro block';
$string['cocoon_course_intro:myaddinstance'] = 'Add a new Course Intro block to the My Moodle page';
$string['config_accent'] = 'Accent';
$string['config_video'] = 'Video Embed URL';
$string['config_teacher'] = 'Teacher';
$string['config_image'] = 'Teacher image';
$string['share'] = 'Share';
