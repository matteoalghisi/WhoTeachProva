<?php
$string['pluginname'] = '[Cocoon] Event Details';
$string['cocoon_event_details'] = '[Cocoon] Event Details';
$string['cocoon_event_details:addinstance'] = 'Add a new Gallery block';
$string['cocoon_event_details:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_date'] = 'Date';
$string['config_time'] = 'Time';
$string['config_location'] = 'Location';
