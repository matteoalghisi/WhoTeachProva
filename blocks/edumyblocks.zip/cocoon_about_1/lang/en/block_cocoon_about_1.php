<?php
$string['pluginname'] = '[Cocoon] About (Text with Image)';
$string['cocoon_about_1'] = '[Cocoon] About (Text with Image)';
$string['cocoon_about_1:addinstance'] = 'Add a new about block with text and an image';
$string['cocoon_about_1:myaddinstance'] = 'Add a new about block with text and an image to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_body'] = 'Body';
$string['config_image'] = 'Image';
