<?php

$string['configtitle'] = 'Block title';
$string['cocoon_featured_video:addinstance'] = 'Add a new [Cocoon] Featured Video block';
$string['cocoon_featured_video:myaddinstance'] = 'Add a new [Cocoon] Featured Video block to Dashboard';
$string['pluginname'] = '[Cocoon] Featured Video';
