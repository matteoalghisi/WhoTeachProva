<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2021090220.38;
$plugin->requires  = 2017051504;
$plugin->component = 'block_cocoon_pills';
