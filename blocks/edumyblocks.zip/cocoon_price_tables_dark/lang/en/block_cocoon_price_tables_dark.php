<?php

$string['configtitle'] = 'Block title';
$string['cocoon_price_tables_dark:addinstance'] = 'Add a new [Cocoon] Price Tables Dark block';
$string['cocoon_price_tables_dark:myaddinstance'] = 'Add a new [Cocoon] Price Tables Dark block to Dashboard';
$string['pluginname'] = '[Cocoon] Price Tables Dark';
