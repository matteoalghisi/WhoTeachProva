<?php

$string['adminview'] = 'Admin view';
$string['allcourses'] = 'Admin user sees all courses';
$string['configadminview'] = 'Whether to display all courses in the Courses block, or only courses that the admin is enrolled in.';
$string['confighideallcourseslink'] = 'Remove the \'All courses\' link under the list of courses. (This setting does not affect the admin view.)';
$string['cocoon_course_categories_3:addinstance'] = 'Add a new courses block';
$string['cocoon_course_categories_3:myaddinstance'] = 'Add a new courses block to Dashboard';
$string['hideallcourseslink'] = 'Hide \'All courses\' link';
$string['owncourses'] = 'Admin user sees own courses';
$string['pluginname'] = '[Cocoon] Course categories 3';
$string['privacy:metadata'] = 'The Cocoon Courses block only shows data about courses and does not store any data itself.';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_link'] = 'Button link';
